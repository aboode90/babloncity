"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trophy, Ticket, Users, Clock, Sparkles } from "lucide-react"
import { toast } from "sonner"

export default function LotteryPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [tickets, setTickets] = useState(10)
  const [entries, setEntries] = useState(0)
  const [timeLeft, setTimeLeft] = useState("3 أيام 12 ساعة")
  const [isEntering, setIsEntering] = useState(false)

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login")
    }
  }, [status, router])

  const handleEnterLottery = async () => {
    if (tickets < 1) {
      toast.error("ليس لديك تذاكر كافية للدخول")
      return
    }

    setIsEntering(true)

    try {
      // محاكاة دخول القرعة
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setTickets(tickets - 1)
      setEntries(entries + 1)
      toast.success("تم دخول القرعة بنجاح!")
    } catch (error) {
      toast.error("حدث خطأ أثناء الدخول")
    } finally {
      setIsEntering(false)
    }
  }

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500 mx-auto mb-4"></div>
          <p className="text-amber-700">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-rose-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 mb-4">
            <Trophy className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-purple-900 mb-2">القرعة الأسبوعية</h1>
          <p className="text-purple-700 text-lg">ادخل القرعة واربح جوائز ضخمة!</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="border-purple-200 bg-gradient-to-br from-purple-100 to-pink-100">
            <CardHeader>
              <CardTitle className="text-purple-900 flex items-center gap-2">
                <Trophy className="h-5 w-5" />
                الجائزة الكبرى
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-900">10,000</div>
              <p className="text-sm text-purple-700 mt-1">عملة ذهبية</p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-gradient-to-br from-pink-100 to-rose-100">
            <CardHeader>
              <CardTitle className="text-pink-900 flex items-center gap-2">
                <Users className="h-5 w-5" />
                المشاركون
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-pink-900">1,234</div>
              <p className="text-sm text-pink-700 mt-1">مشارك حتى الآن</p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 bg-gradient-to-br from-rose-100 to-orange-100">
            <CardHeader>
              <CardTitle className="text-rose-900 flex items-center gap-2">
                <Clock className="h-5 w-5" />
                الوقت المتبقي
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-rose-900">{timeLeft}</div>
              <p className="text-sm text-rose-700 mt-1">حتى السحب</p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-purple-200 mb-8">
          <CardHeader>
            <CardTitle className="text-purple-900 text-2xl flex items-center gap-2">
              <Ticket className="h-6 w-6" />
              ادخل القرعة
            </CardTitle>
            <CardDescription className="text-purple-700">استخدم تذكرة واحدة للدخول في القرعة الأسبوعية</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-6 rounded-xl bg-gradient-to-r from-purple-100 to-pink-100 border-2 border-purple-200">
              <div>
                <p className="text-sm text-purple-700 mb-1">تذاكرك المتاحة</p>
                <div className="text-4xl font-bold text-purple-900 flex items-center gap-2">
                  <Ticket className="h-8 w-8" />
                  {tickets}
                </div>
              </div>
              <div className="text-center">
                <p className="text-sm text-purple-700 mb-1">مشاركاتك</p>
                <div className="text-3xl font-bold text-pink-900">{entries}</div>
              </div>
            </div>

            <Button
              size="lg"
              className="w-full h-14 text-lg font-bold bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white gap-2"
              onClick={handleEnterLottery}
              disabled={isEntering || tickets < 1}
            >
              {isEntering ? (
                <>
                  <Sparkles className="h-5 w-5 animate-spin" />
                  جاري الدخول...
                </>
              ) : (
                <>
                  <Trophy className="h-5 w-5" />
                  ادخل القرعة الآن
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-purple-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-purple-100 flex items-center justify-center mb-2">
                <Trophy className="h-6 w-6 text-purple-600" />
              </div>
              <CardTitle className="text-purple-900">جوائز متعددة</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-purple-700">بالإضافة للجائزة الكبرى، هناك 10 جوائز إضافية للفائزين</p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-pink-100 flex items-center justify-center mb-2">
                <Sparkles className="h-6 w-6 text-pink-600" />
              </div>
              <CardTitle className="text-pink-900">سحب عادل</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-pink-700">جميع المشاركين لديهم فرصة متساوية للفوز بالجوائز</p>
            </CardContent>
          </Card>

          <Card className="border-purple-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 rounded-lg bg-rose-100 flex items-center justify-center mb-2">
                <Clock className="h-6 w-6 text-rose-600" />
              </div>
              <CardTitle className="text-rose-900">أسبوعياً</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-rose-700">قرعة جديدة كل أسبوع مع جوائز رائعة</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
