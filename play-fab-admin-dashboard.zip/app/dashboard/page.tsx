"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Coins, Gift, Trophy, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DashboardPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [userStats, setUserStats] = useState({
    coins: 0,
    gems: 0,
    lastLogin: "",
    rewardsStreak: 0,
  })

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login")
    }
  }, [status, router])

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500 mx-auto mb-4"></div>
          <p className="text-amber-700">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-amber-900 mb-2">لوحة التحكم</h1>
          <p className="text-amber-700">مرحباً بك في حسابك</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-amber-200 bg-gradient-to-br from-yellow-100 to-amber-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-amber-900">العملات الذهبية</CardTitle>
              <Coins className="h-5 w-5 text-amber-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-amber-900">{userStats.coins}</div>
              <p className="text-xs text-amber-700 mt-1">رصيدك الحالي</p>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-gradient-to-br from-blue-100 to-cyan-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-blue-900">الجواهر</CardTitle>
              <Gift className="h-5 w-5 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-900">{userStats.gems}</div>
              <p className="text-xs text-blue-700 mt-1">الجواهر المتاحة</p>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-gradient-to-br from-green-100 to-emerald-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-green-900">سلسلة المكافآت</CardTitle>
              <Trophy className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-900">{userStats.rewardsStreak} يوم</div>
              <p className="text-xs text-green-700 mt-1">حافظ على السلسلة!</p>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-gradient-to-br from-purple-100 to-pink-100">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-purple-900">آخر تسجيل دخول</CardTitle>
              <Calendar className="h-5 w-5 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold text-purple-900">اليوم</div>
              <p className="text-xs text-purple-700 mt-1">نشط الآن</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="border-amber-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-amber-900 flex items-center gap-2">
                <Gift className="h-6 w-6 text-amber-600" />
                المكافآت اليومية
              </CardTitle>
              <CardDescription className="text-amber-700">احصل على مكافآتك اليومية</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-amber-800 mb-4">
                سجل دخولك يومياً واحصل على مكافآت رائعة! كلما حافظت على السلسلة، زادت المكافآت.
              </p>
              <Link href="/rewards">
                <Button className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white font-bold">
                  احصل على المكافأة
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-amber-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="text-amber-900 flex items-center gap-2">
                <Trophy className="h-6 w-6 text-amber-600" />
                القرعة الأسبوعية
              </CardTitle>
              <CardDescription className="text-amber-700">شارك في القرعة واربح جوائز كبيرة</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-amber-800 mb-4">
                استخدم عملاتك الذهبية للدخول في القرعة الأسبوعية واحصل على فرصة للفوز بجوائز ضخمة!
              </p>
              <Link href="/lottery">
                <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold">
                  دخول القرعة
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
