import { NextResponse } from "next/server"
import { searchActivePlayers, getPlayerAccountInfo, getPlayerVirtualCurrency } from "@/lib/playfab"

export async function GET() {
  try {
    // البحث عن اللاعبين النشطين (آخر 30 يومًا)
    const activePlayers = await searchActivePlayers()

    // جلب معلومات تفصيلية لكل لاعب
    const usersWithDetails = await Promise.all(
      activePlayers.map(async (player) => {
        try {
          // جلب معلومات الحساب
          const accountInfo = await getPlayerAccountInfo(player.PlayFabId)

          // جلب العملات الافتراضية
          const virtualCurrency = await getPlayerVirtualCurrency(player.PlayFabId)

          return {
            PlayFabId: player.PlayFabId,
            DisplayName: player.DisplayName || "غير معروف",
            LastLogin: player.LastLogin,
            Created: player.Created,
            Email: accountInfo?.PrivateInfo?.Email || "",
            VirtualCurrency: {
              TK: virtualCurrency.TK || 0,
              PT: virtualCurrency.PT || 0,
            },
          }
        } catch (error) {
          console.error(`[v0] خطأ في جلب معلومات اللاعب ${player.PlayFabId}:`, error)
          return {
            PlayFabId: player.PlayFabId,
            DisplayName: player.DisplayName || "غير معروف",
            LastLogin: player.LastLogin,
            Created: player.Created,
            Email: "",
            VirtualCurrency: { TK: 0, PT: 0 },
          }
        }
      }),
    )

    return NextResponse.json(usersWithDetails)
  } catch (error) {
    console.error("[v0] خطأ في جلب قائمة المستخدمين:", error)
    return NextResponse.json({ error: "فشل في جلب قائمة المستخدمين" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { playFabId, currencyCode, amount } = body

    if (!playFabId || !currencyCode || amount === undefined) {
      return NextResponse.json({ error: "بيانات غير كاملة" }, { status: 400 })
    }

    if (!["TK", "PT"].includes(currencyCode)) {
      return NextResponse.json({ error: "نوع العملة غير صحيح" }, { status: 400 })
    }

    // استيراد الدوال المناسبة
    const { addVirtualCurrency, subtractVirtualCurrency } = await import("@/lib/playfab")

    if (amount > 0) {
      await addVirtualCurrency(playFabId, currencyCode, Math.abs(amount))
    } else if (amount < 0) {
      await subtractVirtualCurrency(playFabId, currencyCode, Math.abs(amount))
    }

    return NextResponse.json({
      success: true,
      message: amount > 0 ? "تمت إضافة العملة بنجاح" : "تم خصم العملة بنجاح",
    })
  } catch (error) {
    console.error("[v0] خطأ في تعديل العملة:", error)
    return NextResponse.json({ error: "فشل في تعديل العملة" }, { status: 500 })
  }
}
