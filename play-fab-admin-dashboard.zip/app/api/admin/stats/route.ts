import { NextResponse } from "next/server"
import { getAllPlayersInSegment } from "@/lib/playfab"

export async function GET() {
  try {
    // جلب جميع اللاعبين من شريحة "All Players"
    const allPlayers = await getAllPlayersInSegment("DB0E5739E3A47535")

    // حساب الإحصائيات
    const totalUsers = allPlayers.length

    // اللاعبون النشطون (آخر 30 يومًا)
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const activeUsers = allPlayers.filter((player) => {
      const lastLogin = new Date(player.LastLogin)
      return lastLogin >= thirtyDaysAgo
    }).length

    // حساب إجمالي العملات الافتراضية
    let totalTickets = 0
    let totalPoints = 0

    allPlayers.forEach((player) => {
      if (player.VirtualCurrencyBalances) {
        totalTickets += player.VirtualCurrencyBalances.TK || 0
        totalPoints += player.VirtualCurrencyBalances.PT || 0
      }
    })

    // حساب المستخدمين الجدد لكل يوم (آخر 7 أيام)
    const newUsersByDay: Array<{ date: string; users: number }> = []
    for (let i = 6; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      date.setHours(0, 0, 0, 0)

      const nextDate = new Date(date)
      nextDate.setDate(nextDate.getDate() + 1)

      const usersOnDay = allPlayers.filter((player) => {
        const created = new Date(player.Created)
        return created >= date && created < nextDate
      }).length

      newUsersByDay.push({
        date: date.toISOString().split("T")[0],
        users: usersOnDay,
      })
    }

    return NextResponse.json({
      totalUsers,
      activeUsers,
      totalTickets,
      totalPoints,
      newUsersByDay,
    })
  } catch (error) {
    console.error("[v0] خطأ في جلب الإحصائيات:", error)
    return NextResponse.json({ error: "فشل في جلب الإحصائيات" }, { status: 500 })
  }
}
