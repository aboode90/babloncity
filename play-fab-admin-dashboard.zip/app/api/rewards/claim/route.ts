import { NextResponse } from "next/server"
import { executeCloudScript } from "@/lib/playfab"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { playFabId } = body

    if (!playFabId) {
      return NextResponse.json({ error: "معرف اللاعب مطلوب" }, { status: 400 })
    }

    // استدعاء Cloud Script للمطالبة بالمكافأة اليومية
    const result = await executeCloudScript(playFabId, "claimDailyReward", { playFabId })

    if (result.Error) {
      return NextResponse.json({ error: result.Error.Message || "فشل في المطالبة بالمكافأة" }, { status: 400 })
    }

    return NextResponse.json({
      message: "تم الحصول على المكافأة اليومية بنجاح",
      result: result.FunctionResult,
    })
  } catch (error) {
    console.error("[v0] خطأ في المطالبة بالمكافأة:", error)
    return NextResponse.json({ error: "فشل في المطالبة بالمكافأة" }, { status: 500 })
  }
}
