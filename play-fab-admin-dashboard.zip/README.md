# Babylon Block Website

بوابة ويب متكاملة لإدارة اللاعبين مع نظام PlayFab ومكافآت يومية تفاعلية.

## المميزات

- 🎮 تكامل كامل مع PlayFab
- 📊 لوحة تحكم إدارية شاملة
- 🎁 نظام مكافآت يومية تلقائي
- 📈 إحصائيات مرئية تفاعلية
- 🔐 نظام مصادقة آمن
- 🌍 دعم كامل للغة العربية (RTL)

## التقنيات المستخدمة

- **Framework**: Next.js 16
- **اللغة**: TypeScript
- **التصميم**: Tailwind CSS v4
- **المكونات**: shadcn/ui
- **الخدمة الخلفية**: PlayFab SDK
- **المصادقة**: NextAuth.js v5
- **الرسوم البيانية**: Recharts
- **إدارة البيانات**: SWR

## البدء

### 1. تثبيت المتطلبات

\`\`\`bash
npm install
\`\`\`

### 2. إعداد متغيرات البيئة

انسخ ملف `.env.local.example` إلى `.env.local` وأضف بياناتك:

\`\`\`env
PLAYFAB_TITLE_ID=your_title_id
PLAYFAB_SECRET_KEY=your_secret_key
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_secret_here
\`\`\`

### 3. إعداد PlayFab Cloud Script

1. اذهب إلى لوحة تحكم PlayFab
2. انتقل إلى: Automation > Cloud Script
3. انسخ محتوى ملف `scripts/playfab-cloud-script.js`
4. الصقه في Cloud Script واحفظ

### 4. تشغيل المشروع

\`\`\`bash
npm run dev
\`\`\`

افتح المتصفح على [http://localhost:3000](http://localhost:3000)

## هيكل المشروع

\`\`\`
/
├── app/
│   ├── api/              # API Routes
│   ├── admin/            # لوحة التحكم
│   ├── rewards/          # صفحة المكافآت
│   └── login/            # صفحة تسجيل الدخول
├── components/           # المكونات القابلة لإعادة الاستخدام
├── lib/                  # الدوال المساعدة
└── scripts/              # SQL Scripts و Cloud Scripts
\`\`\`

## الاستخدام

### لوحة التحكم الإدارية

- عرض الإحصائيات الشاملة
- إدارة اللاعبين
- تعديل العملات الافتراضية (TK و PT)

### المكافآت اليومية

- يمكن للاعبين المطالبة بمكافآتهم كل 24 ساعة
- مكافآت عشوائية من التذاكر والنقاط

## ملاحظات مهمة

### حل مشاكل TypeScript مع PlayFab SDK

المشروع يستخدم تقنيات خاصة للتعامل مع مشاكل التوافق:

- استخدام `any` للأنواع الإشكالية
- تحديد أنواع المعاملات بشكل صريح
- استخدام `FunctionParameter` (مفرد) وليس `FunctionParameters`

## النشر

يمكن نشر المشروع على:

- Vercel (موصى به)
- Firebase Hosting
- أي منصة تدعم Next.js

\`\`\`bash
npm run build
\`\`\`

## الترخيص

MIT License
