import Link from "next/link"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="mt-auto border-t border-amber-200/20 bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950 dark:to-yellow-950">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Image src="/logo.png" alt="Babylon Block" width={40} height={40} />
              <h3 className="text-xl font-bold bg-gradient-to-r from-amber-600 to-yellow-600 bg-clip-text text-transparent">
                Babylon Block
              </h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              منصة ألعاب متكاملة تقدم تجربة ترفيهية فريدة مع مكافآت يومية وجوائز مميزة
            </p>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-amber-700">روابط سريعة</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-amber-600 transition-colors">
                  الصفحة الرئيسية
                </Link>
              </li>
              <li>
                <Link href="/rewards" className="text-muted-foreground hover:text-amber-600 transition-colors">
                  المكافآت اليومية
                </Link>
              </li>
              <li>
                <Link href="/lottery" className="text-muted-foreground hover:text-amber-600 transition-colors">
                  القرعة
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-amber-600 transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h4 className="font-bold text-amber-700">تواصل معنا</h4>
            <p className="text-sm text-muted-foreground">للاستفسارات والدعم الفني</p>
            <p className="text-sm text-amber-600 font-medium">support@babylonblock.com</p>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-amber-200/20 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Babylon Block. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  )
}
