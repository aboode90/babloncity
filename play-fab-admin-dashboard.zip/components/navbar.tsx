"use client"

import Link from "next/link"
import Image from "next/image"
import { useSession, signOut } from "next-auth/react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, LogOut, LayoutDashboard, Gift, Trophy } from "lucide-react"

export function Navbar() {
  const { data: session } = useSession()

  return (
    <nav className="sticky top-0 z-50 border-b border-amber-200/20 backdrop-blur-md bg-gradient-to-r from-amber-50/95 to-yellow-50/95 dark:from-amber-950/95 dark:to-yellow-950/95">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <Image src="/logo.png" alt="Babylon Block" width={50} height={50} className="drop-shadow-lg" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-amber-600 to-yellow-600 bg-clip-text text-transparent">
              Babylon Block
            </h1>
          </Link>

          <div className="flex items-center gap-3">
            {session ? (
              <>
                {(session.user as any)?.isAdmin && (
                  <Link href="/admin">
                    <Button variant="outline" className="gap-2 border-amber-300 hover:bg-amber-100 bg-transparent">
                      <LayoutDashboard className="h-4 w-4" />
                      لوحة الإدارة
                    </Button>
                  </Link>
                )}

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="gap-2 border-amber-300 hover:bg-amber-100 bg-transparent">
                      <User className="h-4 w-4" />
                      {session.user?.name || session.user?.email}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard" className="cursor-pointer">
                        <LayoutDashboard className="ml-2 h-4 w-4" />
                        لوحة التحكم
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/rewards" className="cursor-pointer">
                        <Gift className="ml-2 h-4 w-4" />
                        المكافآت اليومية
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/lottery" className="cursor-pointer">
                        <Trophy className="ml-2 h-4 w-4" />
                        القرعة
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => signOut()} className="text-red-600 cursor-pointer">
                      <LogOut className="ml-2 h-4 w-4" />
                      تسجيل الخروج
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="outline" className="border-amber-300 hover:bg-amber-100 bg-transparent">
                    تسجيل الدخول
                  </Button>
                </Link>
                <Link href="/register">
                  <Button className="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600">
                    إنشاء حساب
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
