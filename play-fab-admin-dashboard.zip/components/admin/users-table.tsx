"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Skeleton } from "@/components/ui/skeleton"
import { Pencil, Coins, Award } from "lucide-react"
import { toast } from "sonner"

interface User {
  PlayFabId: string
  DisplayName: string
  LastLogin: string
  Created: string
  Email: string
  VirtualCurrency: {
    TK: number
    PT: number
  }
}

interface UsersTableProps {
  users?: User[]
  isLoading: boolean
  onUpdate: () => void
}

export function UsersTable({ users, isLoading, onUpdate }: UsersTableProps) {
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [currencyCode, setCurrencyCode] = useState<"TK" | "PT">("TK")
  const [amount, setAmount] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleEditCurrency = async () => {
    if (!editingUser || !amount) return

    setIsSubmitting(true)

    try {
      const response = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          playFabId: editingUser.PlayFabId,
          currencyCode,
          amount: Number.parseInt(amount),
        }),
      })

      const data = await response.json()

      if (response.ok) {
        toast.success(data.message)
        setEditingUser(null)
        setAmount("")
        onUpdate()
      } else {
        toast.error(data.error)
      }
    } catch (error) {
      console.error("[v0] خطأ في تعديل العملة:", error)
      toast.error("حدث خطأ أثناء تعديل العملة")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>جدول اللاعبين</CardTitle>
          <CardDescription>قائمة بجميع اللاعبين النشطين</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!users || users.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>جدول اللاعبين</CardTitle>
          <CardDescription>قائمة بجميع اللاعبين النشطين</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12 text-muted-foreground">لا يوجد لاعبون نشطون حاليًا</div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>جدول اللاعبين</CardTitle>
        <CardDescription>قائمة بجميع اللاعبين النشطين ({users.length} لاعب)</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الاسم</TableHead>
                <TableHead>البريد الإلكتروني</TableHead>
                <TableHead>آخر دخول</TableHead>
                <TableHead className="text-center">التذاكر (TK)</TableHead>
                <TableHead className="text-center">النقاط (PT)</TableHead>
                <TableHead className="text-center">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.PlayFabId}>
                  <TableCell className="font-medium">{user.DisplayName}</TableCell>
                  <TableCell>{user.Email || "غير متوفر"}</TableCell>
                  <TableCell>
                    {new Date(user.LastLogin).toLocaleDateString("ar-EG", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-primary/10 text-primary">
                      <Coins className="h-3 w-3" />
                      {user.VirtualCurrency.TK.toLocaleString()}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-accent/10 text-accent">
                      <Award className="h-3 w-3" />
                      {user.VirtualCurrency.PT.toLocaleString()}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm" onClick={() => setEditingUser(user)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>تعديل العملة - {user.DisplayName}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label>نوع العملة</Label>
                            <Select value={currencyCode} onValueChange={(v) => setCurrencyCode(v as "TK" | "PT")}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="TK">تذاكر (TK)</SelectItem>
                                <SelectItem value="PT">نقاط (PT)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div className="space-y-2">
                            <Label>المبلغ</Label>
                            <Input
                              type="number"
                              placeholder="أدخل المبلغ (موجب للإضافة، سالب للخصم)"
                              value={amount}
                              onChange={(e) => setAmount(e.target.value)}
                            />
                            <p className="text-xs text-muted-foreground">
                              الرصيد الحالي: {user.VirtualCurrency[currencyCode]}
                            </p>
                          </div>

                          <Button onClick={handleEditCurrency} disabled={isSubmitting || !amount} className="w-full">
                            {isSubmitting ? "جاري التعديل..." : "تأكيد"}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
