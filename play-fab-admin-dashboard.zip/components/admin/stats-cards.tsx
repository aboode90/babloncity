import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, UserCheck, Coins, Award } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

interface StatsCardsProps {
  stats?: {
    totalUsers: number
    activeUsers: number
    totalTickets: number
    totalPoints: number
  }
  isLoading: boolean
}

export function StatsCards({ stats, isLoading }: StatsCardsProps) {
  const cards = [
    {
      title: "إجمالي المستخدمين",
      value: stats?.totalUsers || 0,
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "المستخدمون النشطون",
      value: stats?.activeUsers || 0,
      icon: UserCheck,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
    },
    {
      title: "إجمالي التذاكر",
      value: stats?.totalTickets || 0,
      icon: Coins,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      title: "إجمالي النقاط",
      value: stats?.totalPoints || 0,
      icon: Award,
      color: "text-chart-4",
      bgColor: "bg-chart-4/10",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {cards.map((card, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{card.title}</CardTitle>
            <div className={`w-8 h-8 rounded-lg ${card.bgColor} flex items-center justify-center`}>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-24" />
            ) : (
              <div className="text-3xl font-bold">{card.value.toLocaleString()}</div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
