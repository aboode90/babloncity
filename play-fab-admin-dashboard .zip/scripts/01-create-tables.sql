-- إنشاء جدول المكافآت اليومية
CREATE TABLE IF NOT EXISTS daily_rewards (
    id SERIAL PRIMARY KEY,
    playfab_id VARCHAR(255) NOT NULL,
    last_claim_date TIMESTAMP NOT NULL,
    streak_days INTEGER DEFAULT 1,
    total_claims INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء فهرس للبحث السريع
CREATE INDEX IF NOT EXISTS idx_daily_rewards_playfab_id ON daily_rewards(playfab_id);

-- إنشاء جدول سجل المكافآت
CREATE TABLE IF NOT EXISTS rewards_log (
    id SERIAL PRIMARY KEY,
    playfab_id VARCHAR(255) NOT NULL,
    reward_type VARCHAR(50) NOT NULL,
    reward_amount INTEGER NOT NULL,
    currency_code VARCHAR(10) NOT NULL,
    claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- إنشاء فهرس للبحث السريع
CREATE INDEX IF NOT EXISTS idx_rewards_log_playfab_id ON rewards_log(playfab_id);
CREATE INDEX IF NOT EXISTS idx_rewards_log_claimed_at ON rewards_log(claimed_at);
