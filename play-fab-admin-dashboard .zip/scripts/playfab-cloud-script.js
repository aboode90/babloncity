// هذا السكريبت يجب إضافته إلى PlayFab Cloud Script
// في لوحة تحكم PlayFab تحت: Automation > Cloud Script

const handlers = require("./handlers")
const server = require("playfab").ServerSDK

handlers.claimDailyReward = (args, context) => {
  const playFabId = args.playFabId || context.currentPlayerId

  if (!playFabId) {
    return { error: "معرف اللاعب مطلوب" }
  }

  // الحصول على بيانات اللاعب
  const titleDataKey = `DailyReward_${playFabId}`
  const getTitleDataRequest = {
    Keys: [titleDataKey],
  }

  const titleData = server.GetTitleData(getTitleDataRequest)
  let lastClaimDate = null
  let canClaim = true

  if (titleData.Data && titleData.Data[titleDataKey]) {
    lastClaimDate = new Date(JSON.parse(titleData.Data[titleDataKey]).lastClaim)
    const now = new Date()
    const timeDiff = now - lastClaimDate
    const hoursDiff = timeDiff / (1000 * 60 * 60)

    // التحقق من مرور 24 ساعة
    if (hoursDiff < 24) {
      canClaim = false
      const hoursRemaining = Math.ceil(24 - hoursDiff)
      return {
        error: `يجب الانتظار ${hoursRemaining} ساعة قبل المطالبة بالمكافأة التالية`,
      }
    }
  }

  if (!canClaim) {
    return { error: "لقد حصلت على مكافأتك اليومية بالفعل" }
  }

  // منح المكافآت
  const ticketsAmount = Math.floor(Math.random() * 50) + 50 // 50-100 تذكرة
  const pointsAmount = Math.floor(Math.random() * 100) + 100 // 100-200 نقطة

  // إضافة التذاكر
  server.AddUserVirtualCurrency({
    PlayFabId: playFabId,
    VirtualCurrency: "TK",
    Amount: ticketsAmount,
  })

  // إضافة النقاط
  server.AddUserVirtualCurrency({
    PlayFabId: playFabId,
    VirtualCurrency: "PT",
    Amount: pointsAmount,
  })

  // تحديث بيانات آخر مطالبة
  const newClaimData = {
    lastClaim: new Date().toISOString(),
    ticketsReceived: ticketsAmount,
    pointsReceived: pointsAmount,
  }

  server.SetTitleData({
    Key: titleDataKey,
    Value: JSON.stringify(newClaimData),
  })

  return {
    success: true,
    message: "تم الحصول على المكافأة اليومية بنجاح",
    rewards: {
      tickets: ticketsAmount,
      points: pointsAmount,
    },
  }
}
