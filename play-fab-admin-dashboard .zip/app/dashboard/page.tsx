"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Coins, Gift, Trophy, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function DashboardPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [userStats, setUserStats] = useState({
    coins: 0,
    gems: 0,
    lastLogin: "",
    rewardsStreak: 0,
  })

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login")
    }
  }, [status, router])

  if (status === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500 mx-auto mb-4"></div>
          <p className="text-amber-700">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background py-6 sm:py-8 px-3 sm:px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-2">لوحة التحكم</h1>
          <p className="text-sm sm:text-base text-muted-foreground">مرحباً بك في حسابك</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6 mb-6 sm:mb-8">
          <Card className="bg-card border-border glow-primary">
            <CardHeader className="flex flex-row items-center justify-between pb-2 px-3 sm:px-6 pt-3 sm:pt-6">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground">العملات الذهبية</CardTitle>
              <Coins className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
            </CardHeader>
            <CardContent className="px-3 sm:px-6 pb-3 sm:pb-6">
              <div className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground">{userStats.coins}</div>
              <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">رصيدك الحالي</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border glow-secondary">
            <CardHeader className="flex flex-row items-center justify-between pb-2 px-3 sm:px-6 pt-3 sm:pt-6">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground">الجواهر</CardTitle>
              <Gift className="h-4 w-4 sm:h-5 sm:w-5 text-secondary" />
            </CardHeader>
            <CardContent className="px-3 sm:px-6 pb-3 sm:pb-6">
              <div className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground">{userStats.gems}</div>
              <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">الجواهر المتاحة</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border glow-primary">
            <CardHeader className="flex flex-row items-center justify-between pb-2 px-3 sm:px-6 pt-3 sm:pt-6">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground">سلسلة المكافآت</CardTitle>
              <Trophy className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
            </CardHeader>
            <CardContent className="px-3 sm:px-6 pb-3 sm:pb-6">
              <div className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground">
                {userStats.rewardsStreak} يوم
              </div>
              <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">حافظ على السلسلة!</p>
            </CardContent>
          </Card>

          <Card className="bg-card border-border glow-accent">
            <CardHeader className="flex flex-row items-center justify-between pb-2 px-3 sm:px-6 pt-3 sm:pt-6">
              <CardTitle className="text-xs sm:text-sm font-medium text-foreground">آخر تسجيل دخول</CardTitle>
              <Calendar className="h-4 w-4 sm:h-5 sm:w-5 text-accent" />
            </CardHeader>
            <CardContent className="px-3 sm:px-6 pb-3 sm:pb-6">
              <div className="text-base sm:text-lg font-bold text-foreground">اليوم</div>
              <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">نشط الآن</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          <Card className="bg-card border-border hover:shadow-xl transition-shadow glow-primary">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <Gift className="h-6 w-6 text-primary" />
                المكافآت اليومية
              </CardTitle>
              <CardDescription className="text-muted-foreground">احصل على مكافآتك اليومية</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                سجل دخولك يومياً واحصل على مكافآت رائعة! كلما حافظت على السلسلة، زادت المكافآت.
              </p>
              <Link href="/rewards">
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold glow-primary">
                  احصل على المكافأة
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-card border-border hover:shadow-xl transition-shadow glow-accent">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <Trophy className="h-6 w-6 text-accent" />
                القرعة الأسبوعية
              </CardTitle>
              <CardDescription className="text-muted-foreground">شارك في القرعة واربح جوائز كبيرة</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                استخدم عملاتك الذهبية للدخول في القرعة الأسبوعية واحصل على فرصة للفوز بجوائز ضخمة!
              </p>
              <Link href="/lottery">
                <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold glow-accent">
                  دخول القرعة
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
