"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

export default function RegisterPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      toast.error("كلمات المرور غير متطابقة")
      return
    }

    if (formData.password.length < 6) {
      toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل")
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("https://titleId.playfabapi.com/Client/RegisterPlayFabUser", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-PlayFabSDK": "JavaScriptSDK-1.0.0",
        },
        body: JSON.stringify({
          TitleId: process.env.NEXT_PUBLIC_PLAYFAB_TITLE_ID,
          Username: formData.username,
          Email: formData.email,
          Password: formData.password,
          RequireBothUsernameAndEmail: true,
        }),
      })

      const data = await response.json()

      if (data.code === 200) {
        toast.success("تم إنشاء الحساب بنجاح!")
        setTimeout(() => {
          router.push("/login")
        }, 1500)
      } else {
        toast.error(data.errorMessage || "فشل إنشاء الحساب")
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الحساب")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 p-4">
      <Card className="w-full max-w-md border-amber-200 shadow-xl">
        <CardHeader className="text-center">
          <div className="w-20 h-20 mx-auto mb-4">
            <img src="/logo.png" alt="Babylon Block" className="w-full h-full object-contain" />
          </div>
          <CardTitle className="text-3xl font-bold text-amber-900">إنشاء حساب جديد</CardTitle>
          <CardDescription className="text-amber-700">انضم إلى Babylon Block واحصل على المكافآت</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-amber-900">
                اسم المستخدم
              </Label>
              <Input
                id="username"
                type="text"
                placeholder="اسم المستخدم"
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="border-amber-300 focus:border-amber-500"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-amber-900">
                البريد الإلكتروني
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="border-amber-300 focus:border-amber-500"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-amber-900">
                كلمة المرور
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="border-amber-300 focus:border-amber-500"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-amber-900">
                تأكيد كلمة المرور
              </Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="border-amber-300 focus:border-amber-500"
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white font-bold"
              disabled={isLoading}
            >
              {isLoading ? "جاري إنشاء الحساب..." : "إنشاء حساب"}
            </Button>

            <div className="text-center text-sm text-amber-700">
              لديك حساب بالفعل؟{" "}
              <Link href="/login" className="text-amber-900 font-bold hover:underline">
                تسجيل الدخول
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
