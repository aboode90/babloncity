import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Gift, Trophy, Coins, Shield, Star, Users } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="container mx-auto px-4 sm:px-6 py-12 sm:py-16 md:py-20">
        <div className="text-center max-w-4xl mx-auto space-y-6 sm:space-y-8">
          <div className="flex justify-center">
            <Image
              src="/logo.png"
              alt="Babylon Block"
              width={150}
              height={150}
              className="drop-shadow-2xl animate-pulse sm:w-[200px] sm:h-[200px]"
            />
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance text-foreground px-2">
            مرحباً بك في Babylon Block
          </h1>
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-muted-foreground text-pretty leading-relaxed px-4">
            استمتع بتجربة ألعاب فريدة، احصل على مكافآت يومية، وشارك في القرعة للفوز بجوائز مميزة
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 pt-4 sm:pt-6 px-4">
            <Link href="/register" className="w-full sm:w-auto">
              <Button
                size="lg"
                className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-8 bg-primary hover:bg-primary/90 text-primary-foreground glow-primary"
              >
                <Star className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
                ابدأ الآن مجاناً
              </Button>
            </Link>
            <Link href="/login" className="w-full sm:w-auto">
              <Button
                size="lg"
                variant="outline"
                className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-8 bg-transparent"
              >
                تسجيل الدخول
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center mb-8 sm:mb-12 text-foreground px-2">
          ماذا نقدم لك؟
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          <Card className="p-8 space-y-4 hover:shadow-xl transition-all glow-primary bg-card">
            <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
              <Gift className="h-8 w-8 text-primary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground">مكافآت يومية</h3>
            <p className="text-muted-foreground leading-relaxed">
              احصل على مكافآت قيمة كل يوم! سجل دخولك يومياً واحصل على عملات ذهبية وجواهر مجانية
            </p>
          </Card>

          <Card className="p-8 space-y-4 hover:shadow-xl transition-all glow-secondary bg-card">
            <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center shadow-lg">
              <Trophy className="h-8 w-8 text-secondary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground">القرعة الأسبوعية</h3>
            <p className="text-muted-foreground leading-relaxed">
              شارك في القرعة الأسبوعية للفوز بجوائز ضخمة وعملات إضافية وهدايا حصرية
            </p>
          </Card>

          <Card className="p-8 space-y-4 hover:shadow-xl transition-all glow-accent bg-card">
            <div className="w-16 h-16 rounded-2xl bg-accent flex items-center justify-center shadow-lg">
              <Coins className="h-8 w-8 text-accent-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground">عملات وجواهر</h3>
            <p className="text-muted-foreground leading-relaxed">
              اجمع العملات الذهبية والجواهر لتطوير حسابك والحصول على مزايا إضافية
            </p>
          </Card>

          <Card className="p-8 space-y-4 hover:shadow-xl transition-all glow-secondary bg-card">
            <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center shadow-lg">
              <Shield className="h-8 w-8 text-secondary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground">أمان وحماية</h3>
            <p className="text-muted-foreground leading-relaxed">
              حسابك محمي بأحدث تقنيات الأمان مع نظام PlayFab المتقدم
            </p>
          </Card>

          <Card className="p-8 space-y-4 hover:shadow-xl transition-all glow-accent bg-card">
            <div className="w-16 h-16 rounded-2xl bg-accent flex items-center justify-center shadow-lg">
              <Star className="h-8 w-8 text-accent-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground">تجربة فريدة</h3>
            <p className="text-muted-foreground leading-relaxed">
              واجهة سهلة الاستخدام وتصميم عصري يوفر أفضل تجربة للمستخدم
            </p>
          </Card>

          <Card className="p-8 space-y-4 hover:shadow-xl transition-all glow-primary bg-card">
            <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg">
              <Users className="h-8 w-8 text-primary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground">مجتمع نشط</h3>
            <p className="text-muted-foreground leading-relaxed">
              انضم إلى آلاف اللاعبين وشارك في المنافسات والفعاليات الخاصة
            </p>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 sm:px-6 py-12 sm:py-16 md:py-20">
        <Card className="p-6 sm:p-8 md:p-12 text-center bg-card glow-primary shadow-2xl">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6 text-foreground">جاهز للبدء؟</h2>
          <p className="text-base sm:text-lg md:text-xl text-muted-foreground mb-6 sm:mb-8 max-w-2xl mx-auto px-2">
            أنشئ حسابك الآن واحصل على 1000 عملة ذهبية مجانية كهدية ترحيبية
          </p>
          <Link href="/register">
            <Button
              size="lg"
              className="text-base sm:text-lg md:text-xl px-8 sm:px-10 md:px-12 py-4 sm:py-5 md:py-6 bg-primary hover:bg-primary/90 text-primary-foreground glow-primary"
            >
              سجل مجاناً الآن
            </Button>
          </Link>
        </Card>
      </section>
    </div>
  )
}
