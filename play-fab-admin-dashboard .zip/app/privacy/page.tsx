import { Card } from "@/components/ui/card"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 dark:from-amber-950 dark:via-yellow-950 dark:to-orange-950">
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <h1 className="text-5xl font-bold text-center mb-8 bg-gradient-to-r from-amber-600 to-yellow-600 bg-clip-text text-transparent">
          سياسة الخصوصية
        </h1>

        <Card className="p-8 space-y-8 border-amber-200">
          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">مقدمة</h2>
            <p className="text-muted-foreground leading-relaxed">
              نحن في Babylon Block نحترم خصوصيتك ونلتزم بحماية بياناتك الشخصية. توضح سياسة الخصوصية هذه كيفية جمع
              واستخدام وحماية المعلومات التي تقدمها لنا عند استخدام منصتنا.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">المعلومات التي نجمعها</h2>
            <div className="space-y-3 text-muted-foreground leading-relaxed">
              <p className="font-semibold text-foreground">نقوم بجمع المعلومات التالية:</p>
              <ul className="list-disc list-inside space-y-2 mr-6">
                <li>البريد الإلكتروني وكلمة المرور عند التسجيل</li>
                <li>معلومات الحساب مثل اسم المستخدم والمستوى</li>
                <li>بيانات اللعب والإحصائيات داخل المنصة</li>
                <li>العملات الافتراضية والجواهر المكتسبة</li>
                <li>سجل المكافآت والقرعة</li>
              </ul>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">كيفية استخدام المعلومات</h2>
            <div className="space-y-3 text-muted-foreground leading-relaxed">
              <p>نستخدم المعلومات المجمعة للأغراض التالية:</p>
              <ul className="list-disc list-inside space-y-2 mr-6">
                <li>إنشاء وإدارة حسابك على المنصة</li>
                <li>توفير خدمات المكافآت اليومية والقرعة</li>
                <li>تحسين تجربة المستخدم وتطوير المنصة</li>
                <li>التواصل معك بخصوص التحديثات والعروض</li>
                <li>ضمان أمان المنصة ومنع الاحتيال</li>
              </ul>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">حماية البيانات</h2>
            <p className="text-muted-foreground leading-relaxed">
              نستخدم تقنية PlayFab المتقدمة لحماية بياناتك. يتم تشفير جميع المعلومات الحساسة مثل كلمات المرور، ونتخذ
              إجراءات أمنية صارمة لمنع الوصول غير المصرح به إلى بياناتك الشخصية.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">مشاركة المعلومات</h2>
            <p className="text-muted-foreground leading-relaxed">
              نحن لا نبيع أو نشارك معلوماتك الشخصية مع أطراف ثالثة لأغراض تسويقية. قد نشارك بيانات محدودة مع مزودي
              الخدمات الضروريين لتشغيل المنصة مثل PlayFab، وذلك فقط في حدود ما هو ضروري لتقديم الخدمة.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">حقوقك</h2>
            <div className="space-y-3 text-muted-foreground leading-relaxed">
              <p>لديك الحقوق التالية فيما يتعلق ببياناتك:</p>
              <ul className="list-disc list-inside space-y-2 mr-6">
                <li>الوصول إلى بياناتك الشخصية ومراجعتها</li>
                <li>تعديل أو تحديث معلومات حسابك</li>
                <li>طلب حذف حسابك وبياناتك</li>
                <li>الاعتراض على معالجة بياناتك</li>
                <li>سحب موافقتك في أي وقت</li>
              </ul>
            </div>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">ملفات تعريف الارتباط (Cookies)</h2>
            <p className="text-muted-foreground leading-relaxed">
              نستخدم ملفات تعريف الارتباط لتحسين تجربتك على المنصة وحفظ تفضيلاتك. يمكنك التحكم في إعدادات ملفات تعريف
              الارتباط من خلال متصفحك، لكن تعطيلها قد يؤثر على وظائف معينة في المنصة.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">التحديثات على السياسة</h2>
            <p className="text-muted-foreground leading-relaxed">
              قد نقوم بتحديث سياسة الخصوصية من وقت لآخر. سنقوم بإعلامك بأي تغييرات جوهرية عبر البريد الإلكتروني أو من
              خلال إشعار على المنصة. ننصحك بمراجعة هذه الصفحة بشكل دوري للاطلاع على أي تحديثات.
            </p>
          </section>

          <section className="space-y-4">
            <h2 className="text-3xl font-bold text-amber-900">تواصل معنا</h2>
            <p className="text-muted-foreground leading-relaxed">
              إذا كان لديك أي أسئلة أو استفسارات حول سياسة الخصوصية أو بياناتك الشخصية، يمكنك التواصل معنا عبر البريد
              الإلكتروني:
            </p>
            <p className="text-amber-600 font-semibold text-lg">support@babylonblock.com</p>
          </section>

          <div className="pt-6 border-t border-amber-200">
            <p className="text-center text-muted-foreground">
              آخر تحديث: {new Date().toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" })}
            </p>
          </div>
        </Card>
      </div>
    </div>
  )
}
