"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Gift, Sparkles, ArrowRight, Coins, Award } from "lucide-react"
import { toast } from "sonner"

export default function RewardsPage() {
  const [playFabId, setPlayFabId] = useState("")
  const [isClaiming, setIsClaiming] = useState(false)
  const [lastClaim, setLastClaim] = useState<string | null>(null)

  const handleClaimReward = async () => {
    if (!playFabId.trim()) {
      toast.error("يرجى إدخال معرف اللاعب")
      return
    }

    setIsClaiming(true)

    try {
      const response = await fetch("/api/rewards/claim", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playFabId: playFabId.trim() }),
      })

      const data = await response.json()

      if (response.ok) {
        toast.success("تم الحصول على المكافأة اليومية بنجاح!")
        setLastClaim(new Date().toLocaleString("ar-EG"))
      } else {
        toast.error(data.error || "فشل في المطالبة بالمكافأة")
      }
    } catch (error) {
      console.error("[v0] خطأ في المطالبة بالمكافأة:", error)
      toast.error("حدث خطأ أثناء المطالبة بالمكافأة")
    } finally {
      setIsClaiming(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50">
      {/* Navigation */}
      <nav className="border-b border-border/40 backdrop-blur-sm bg-background/80">
        <div className="container mx-auto px-3 sm:px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 sm:gap-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-base sm:text-xl">BB</span>
              </div>
              <h1 className="text-lg sm:text-xl md:text-2xl font-bold">Babylon Block</h1>
            </Link>
            <Link href="/admin">
              <Button variant="ghost" className="text-sm sm:text-base px-2 sm:px-4">
                <span className="hidden sm:inline">لوحة التحكم</span>
                <span className="sm:hidden">الإدارة</span>
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-3 sm:px-4 py-8 sm:py-12 md:py-16">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center space-y-3 sm:space-y-4 mb-8 sm:mb-12">
            <div className="w-24 h-24 sm:w-28 sm:h-28 md:w-32 md:h-32 mx-auto mb-4 sm:mb-6">
              <img src="/logo.png" alt="Babylon Block" className="w-full h-full object-contain" />
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-balance text-amber-900 px-2">
              المكافآت اليومية
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-amber-700 text-pretty leading-relaxed max-w-2xl mx-auto px-3">
              احصل على مكافأتك اليومية من التذاكر والنقاط لتعزيز تجربتك في اللعبة
            </p>
          </div>

          {/* Main Reward Card */}
          <Card className="p-4 sm:p-6 md:p-8 space-y-6 sm:space-y-8 bg-white/80 backdrop-blur-sm border-2 border-amber-200 shadow-xl">
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="playFabId" className="text-lg">
                  معرف اللاعب (PlayFab ID)
                </Label>
                <Input
                  id="playFabId"
                  type="text"
                  placeholder="أدخل معرف اللاعب الخاص بك"
                  value={playFabId}
                  onChange={(e) => setPlayFabId(e.target.value)}
                  className="h-14 text-lg"
                  disabled={isClaiming}
                />
              </div>

              <Button
                size="lg"
                className="w-full h-14 text-lg font-bold gap-2"
                onClick={handleClaimReward}
                disabled={isClaiming || !playFabId.trim()}
              >
                {isClaiming ? (
                  <>
                    <Sparkles className="h-5 w-5 animate-spin" />
                    جاري المطالبة...
                  </>
                ) : (
                  <>
                    <Gift className="h-5 w-5" />
                    احصل على مكافأتك الآن
                    <ArrowRight className="h-5 w-5" />
                  </>
                )}
              </Button>

              {lastClaim && (
                <div className="p-4 rounded-lg bg-accent/10 border border-accent/20 text-center">
                  <p className="text-sm text-muted-foreground">آخر مطالبة</p>
                  <p className="font-bold text-accent">{lastClaim}</p>
                </div>
              )}
            </div>

            {/* Rewards Info */}
            <div className="grid md:grid-cols-2 gap-4 pt-6 border-t">
              <div className="p-6 rounded-xl bg-primary/5 border border-primary/10 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Coins className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">التذاكر</h3>
                    <p className="text-sm text-muted-foreground">TK Currency</p>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  استخدم التذاكر للدخول إلى المسابقات الخاصة والحصول على محتوى حصري
                </p>
              </div>

              <div className="p-6 rounded-xl bg-accent/5 border border-accent/10 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                    <Award className="h-6 w-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">النقاط</h3>
                    <p className="text-sm text-muted-foreground">PT Currency</p>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  اجمع النقاط لترتقي في لوحة المتصدرين واحصل على مكافآت إضافية
                </p>
              </div>
            </div>
          </Card>

          {/* Info Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6 mt-6 sm:mt-8">
            <Card className="p-6 text-center space-y-3 hover:shadow-lg transition-shadow border-amber-200">
              <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mx-auto">
                <Sparkles className="h-8 w-8 text-amber-600" />
              </div>
              <h3 className="font-bold text-lg text-amber-900">يوميًا</h3>
              <p className="text-sm text-amber-700 leading-relaxed">احصل على مكافأتك مرة واحدة كل 24 ساعة</p>
            </Card>

            <Card className="p-6 text-center space-y-3 hover:shadow-lg transition-shadow border-amber-200">
              <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center mx-auto">
                <Gift className="h-8 w-8 text-yellow-600" />
              </div>
              <h3 className="font-bold text-lg text-amber-900">مكافآت متنوعة</h3>
              <p className="text-sm text-amber-700 leading-relaxed">احصل على تذاكر ونقاط مختلفة كل يوم</p>
            </Card>

            <Card className="p-6 text-center space-y-3 hover:shadow-lg transition-shadow border-amber-200">
              <div className="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center mx-auto">
                <Award className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="font-bold text-lg text-amber-900">تلقائي</h3>
              <p className="text-sm text-amber-700 leading-relaxed">لا حاجة للإعدادات، فقط أدخل معرفك واحصل</p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
