"use client"
import useSWR from "swr"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, TrendingUp, Coins, Award } from "lucide-react"
import { StatsCards } from "@/components/admin/stats-cards"
import { UsersTable } from "@/components/admin/users-table"
import { NewUsersChart } from "@/components/admin/new-users-chart"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export default function AdminPage() {
  const { data: stats, isLoading: statsLoading } = useSWR("/api/admin/stats", fetcher, {
    refreshInterval: 30000, // تحديث كل 30 ثانية
  })

  const {
    data: users,
    isLoading: usersLoading,
    mutate: mutateUsers,
  } = useSWR("/api/admin/users", fetcher, {
    refreshInterval: 30000,
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-gray-50 to-zinc-50">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-4 mb-2">
                <img src="/logo.png" alt="Babylon Block" className="w-12 h-12 object-contain" />
                <h1 className="text-3xl font-bold text-gray-900">لوحة التحكم - الإدارة</h1>
              </div>
              <p className="text-gray-600 mt-1">إدارة ومراقبة اللاعبين والإحصائيات</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold">BB</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-muted">
            <TabsTrigger value="overview" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="users" className="gap-2">
              <Users className="h-4 w-4" />
              إدارة اللاعبين
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <StatsCards stats={stats} isLoading={statsLoading} />

            {/* Charts */}
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>المستخدمون الجدد</CardTitle>
                  <CardDescription>عدد التسجيلات الجديدة في آخر 7 أيام</CardDescription>
                </CardHeader>
                <CardContent>
                  <NewUsersChart data={stats?.newUsersByDay} isLoading={statsLoading} />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>توزيع العملات</CardTitle>
                  <CardDescription>إجمالي العملات الافتراضية في النظام</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-lg bg-primary/5 border border-primary/10">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Coins className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">التذاكر (TK)</p>
                          <p className="text-2xl font-bold">{stats?.totalTickets?.toLocaleString() || 0}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 rounded-lg bg-accent/5 border border-accent/10">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                          <Award className="h-5 w-5 text-accent" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">النقاط (PT)</p>
                          <p className="text-2xl font-bold">{stats?.totalPoints?.toLocaleString() || 0}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <UsersTable users={users} isLoading={usersLoading} onUpdate={mutateUsers} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
