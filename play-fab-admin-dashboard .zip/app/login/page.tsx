"use client"

import type React from "react"

import { useState } from "react"
import { signIn } from "next-auth/react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const result = await signIn("credentials", {
        email,
        password,
        redirect: false,
      })

      if (result?.error) {
        toast.error("فشل تسجيل الدخول. تحقق من البيانات.")
      } else {
        toast.success("تم تسجيل الدخول بنجاح")
        router.push("/dashboard")
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء تسجيل الدخول")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 p-4">
      <Card className="w-full max-w-md border-amber-200 shadow-xl">
        <CardHeader className="text-center">
          <div className="w-24 h-24 mx-auto mb-4">
            <img src="/logo.png" alt="Babylon Block" className="w-full h-full object-contain" />
          </div>
          <CardTitle className="text-3xl font-bold text-amber-900">تسجيل الدخول</CardTitle>
          <CardDescription className="text-amber-700">أدخل بياناتك للوصول إلى حسابك</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-amber-900">
                البريد الإلكتروني
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border-amber-300 focus:border-amber-500"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-amber-900">
                كلمة المرور
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border-amber-300 focus:border-amber-500"
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white font-bold"
              disabled={isLoading}
            >
              {isLoading ? "جاري التسجيل..." : "تسجيل الدخول"}
            </Button>

            <div className="text-center text-sm text-amber-700 space-y-2">
              <div>
                ليس لديك حساب؟{" "}
                <Link href="/register" className="text-amber-900 font-bold hover:underline">
                  إنشاء حساب جديد
                </Link>
              </div>
              <div>
                <Link href="/" className="hover:text-amber-900 transition-colors">
                  العودة إلى الصفحة الرئيسية
                </Link>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
