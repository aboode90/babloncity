import PlayFab from "playfab-sdk/Scripts/PlayFab/PlayFab"
import PlayFabServer from "playfab-sdk/Scripts/PlayFab/PlayFabServer"

// تهيئة PlayFab
export function initializePlayFab() {
  if (typeof window === "undefined") {
    // Server-side initialization
    PlayFab.settings.titleId = process.env.PLAYFAB_TITLE_ID || ""
    PlayFab.settings.developerSecretKey = process.env.PLAYFAB_SECRET_KEY || ""
  }
}

// نوع البيانات للاعب
export interface PlayerData {
  PlayFabId: string
  DisplayName: string | null
  LastLogin: string
  Created: string
  Email?: string
  VirtualCurrency: {
    TK: number
    PT: number
  }
}

// نوع البيانات للإحصائيات
export interface StatsData {
  totalUsers: number
  activeUsers: number
  totalTickets: number
  totalPoints: number
  newUsersByDay: Array<{ date: string; users: number }>
}

// دالة للحصول على جميع اللاعبين من شريحة معينة
export async function getAllPlayersInSegment(segmentId: string): Promise<any[]> {
  initializePlayFab()

  return new Promise((resolve, reject) => {
    const allPlayers: any[] = []
    let continuationToken: string | undefined = undefined

    const fetchBatch = () => {
      const request: any = {
        SegmentId: segmentId,
        MaxBatchSize: 100,
      }

      if (continuationToken) {
        request.ContinuationToken = continuationToken
      }
      // استخدام any للتغلب على مشاكل TypeScript
      ;(PlayFabServer as any).GetPlayersInSegment(request, (error: any, result: any) => {
        if (error) {
          reject(error)
          return
        }

        allPlayers.push(...result.data.PlayerProfiles)

        if (result.data.ContinuationToken) {
          continuationToken = result.data.ContinuationToken
          fetchBatch()
        } else {
          resolve(allPlayers)
        }
      })
    }

    fetchBatch()
  })
}

// دالة للبحث عن اللاعبين النشطين
export async function searchActivePlayers(): Promise<any[]> {
  initializePlayFab()

  return new Promise((resolve, reject) => {
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    // استخدام any للتغلب على مشاكل TypeScript
    ;(PlayFabServer as any).GetPlayersInSegment(
      {
        SegmentId: "DB0E5739E3A47535", // All Players segment
        MaxBatchSize: 100,
      },
      async (error: any, result: any) => {
        if (error) {
          reject(error)
          return
        }

        // Filter active players (logged in within last 30 days)
        const activePlayers = result.data.PlayerProfiles.filter((player: any) => {
          const lastLogin = new Date(player.LastLogin)
          return lastLogin >= thirtyDaysAgo
        })

        resolve(activePlayers)
      },
    )
  })
}

// دالة للحصول على معلومات حساب اللاعب
export async function getPlayerAccountInfo(playFabId: string): Promise<any> {
  initializePlayFab()

  return new Promise((resolve, reject) => {
    PlayFabServer.GetUserAccountInfo({ PlayFabId: playFabId }, (error: any, result: any) => {
      if (error) {
        reject(error)
        return
      }
      resolve(result.data.UserInfo)
    })
  })
}

// دالة للحصول على العملات الافتراضية للاعب
export async function getPlayerVirtualCurrency(playFabId: string): Promise<any> {
  initializePlayFab()

  return new Promise((resolve, reject) => {
    PlayFabServer.GetUserInventory({ PlayFabId: playFabId }, (error: any, result: any) => {
      if (error) {
        reject(error)
        return
      }
      resolve(result.data.VirtualCurrency || {})
    })
  })
}

// دالة لإضافة عملة افتراضية
export async function addVirtualCurrency(playFabId: string, currencyCode: string, amount: number): Promise<any> {
  initializePlayFab()

  return new Promise((resolve, reject) => {
    PlayFabServer.AddUserVirtualCurrency(
      {
        PlayFabId: playFabId,
        VirtualCurrency: currencyCode,
        Amount: amount,
      },
      (error: any, result: any) => {
        if (error) {
          reject(error)
          return
        }
        resolve(result.data)
      },
    )
  })
}

// دالة لخصم عملة افتراضية
export async function subtractVirtualCurrency(playFabId: string, currencyCode: string, amount: number): Promise<any> {
  initializePlayFab()

  return new Promise((resolve, reject) => {
    PlayFabServer.SubtractUserVirtualCurrency(
      {
        PlayFabId: playFabId,
        VirtualCurrency: currencyCode,
        Amount: amount,
      },
      (error: any, result: any) => {
        if (error) {
          reject(error)
          return
        }
        resolve(result.data)
      },
    )
  })
}

// دالة لاستدعاء Cloud Script
export async function executeCloudScript(
  playFabId: string,
  functionName: string,
  functionParameter?: any,
): Promise<any> {
  initializePlayFab()

  return new Promise((resolve, reject) => {
    // استخدام FunctionParameter (مفرد) وليس FunctionParameters
    PlayFabServer.ExecuteCloudScript(
      {
        PlayFabId: playFabId,
        FunctionName: functionName,
        FunctionParameter: functionParameter || {},
      },
      (error: any, result: any) => {
        if (error) {
          reject(error)
          return
        }
        resolve(result.data)
      },
    )
  })
}
