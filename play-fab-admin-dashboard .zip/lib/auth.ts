import type { NextAuthOptions } from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import PlayFab from "playfab-sdk/Scripts/PlayFab/PlayFab"
import PlayFabClient from "playfab-sdk/Scripts/PlayFab/PlayFabClient"

export const isAdmin = (email: string | null | undefined) => {
  return email === "abdullaalbder185@gmail.com"
}

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "PlayFab",
      credentials: {
        email: { label: "البريد الإلكتروني", type: "email" },
        password: { label: "كلمة المرور", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        // تهيئة PlayFab
        PlayFab.settings.titleId = process.env.PLAYFAB_TITLE_ID || ""

        return new Promise((resolve) => {
          PlayFabClient.LoginWithEmailAddress(
            {
              TitleId: PlayFab.settings.titleId,
              Email: credentials.email,
              Password: credentials.password,
            },
            (error: any, result: any) => {
              if (error || !result) {
                resolve(null)
                return
              }

              // إرجاع معلومات المستخدم
              resolve({
                id: result.data.PlayFabId,
                email: credentials.email,
                name: result.data.InfoResultPayload?.AccountInfo?.Username || credentials.email,
                playFabId: result.data.PlayFabId,
              })
            },
          )
        })
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.playFabId = (user as any).playFabId
        token.email = user.email
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        ;(session.user as any).playFabId = token.playFabId
        ;(session.user as any).isAdmin = isAdmin(token.email as string)
      }
      return session
    },
  },
  pages: {
    signIn: "/login",
  },
  session: {
    strategy: "jwt",
  },
}
