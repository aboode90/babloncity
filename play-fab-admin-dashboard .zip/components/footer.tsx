import Link from "next/link"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="mt-auto border-t border-white/10 bg-background">
      <div className="container mx-auto px-3 sm:px-4 py-6 sm:py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 sm:gap-8">
          <div className="space-y-3 sm:space-y-4 text-center sm:text-right">
            <div className="flex items-center gap-2 sm:gap-3 justify-center sm:justify-start">
              <Image src="/logo.png" alt="Babylon Block" width={35} height={35} className="sm:w-[40px] sm:h-[40px]" />
              <h3 className="text-lg sm:text-xl font-bold text-primary">Babylon Block</h3>
            </div>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed px-2 sm:px-0">
              منصة ألعاب متكاملة تقدم تجربة ترفيهية فريدة مع مكافآت يومية وجوائز مميزة
            </p>
          </div>

          <div className="space-y-3 sm:space-y-4 text-center sm:text-right">
            <h4 className="font-bold text-foreground text-sm sm:text-base">روابط سريعة</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
                  الصفحة الرئيسية
                </Link>
              </li>
              <li>
                <Link href="/rewards" className="text-muted-foreground hover:text-primary transition-colors">
                  المكافآت اليومية
                </Link>
              </li>
              <li>
                <Link href="/lottery" className="text-muted-foreground hover:text-primary transition-colors">
                  القرعة
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-primary transition-colors">
                  سياسة الخصوصية
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-3 sm:space-y-4 text-center sm:text-right">
            <h4 className="font-bold text-foreground text-sm sm:text-base">تواصل معنا</h4>
            <p className="text-xs sm:text-sm text-muted-foreground">للاستفسارات والدعم الفني</p>
            <p className="text-xs sm:text-sm text-primary font-medium break-all px-2 sm:px-0">
              support@babylonblock.com
            </p>
          </div>
        </div>

        <div className="mt-6 sm:mt-8 pt-4 sm:pt-6 border-t border-white/10 text-center">
          <p className="text-xs sm:text-sm text-muted-foreground px-2">
            © {new Date().getFullYear()} Babylon Block. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  )
}
