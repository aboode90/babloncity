"use client"

import Link from "next/link"
import Image from "next/image"
import { useSession, signOut } from "next-auth/react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, LogOut, LayoutDashboard, Gift, Trophy } from "lucide-react"

export function Navbar() {
  const { data: session } = useSession()

  return (
    <nav className="sticky top-0 z-50 border-b border-border backdrop-blur-md bg-background/95">
      <div className="container mx-auto px-3 sm:px-4 py-2.5 sm:py-3">
        <div className="flex items-center justify-between gap-2">
          <Link href="/" className="flex items-center gap-2 sm:gap-3 hover:opacity-80 transition-opacity">
            <Image
              src="/logo.png"
              alt="Babylon Block"
              width={40}
              height={40}
              className="drop-shadow-lg sm:w-[50px] sm:h-[50px]"
            />
            <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-foreground hidden xs:block">Babylon Block</h1>
          </Link>

          <div className="flex items-center gap-2 sm:gap-3">
            {session ? (
              <>
                {(session.user as any)?.isAdmin && (
                  <Link href="/admin" className="hidden md:block">
                    <Button variant="outline" className="gap-2 bg-transparent text-sm">
                      <LayoutDashboard className="h-4 w-4" />
                      <span className="hidden lg:inline">لوحة الإدارة</span>
                    </Button>
                  </Link>
                )}

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="gap-2 bg-transparent text-sm px-2 sm:px-4">
                      <User className="h-4 w-4" />
                      <span className="hidden sm:inline max-w-[100px] md:max-w-[150px] truncate">
                        {session.user?.name || session.user?.email}
                      </span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard" className="cursor-pointer">
                        <LayoutDashboard className="ml-2 h-4 w-4" />
                        لوحة التحكم
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/rewards" className="cursor-pointer">
                        <Gift className="ml-2 h-4 w-4" />
                        المكافآت اليومية
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/lottery" className="cursor-pointer">
                        <Trophy className="ml-2 h-4 w-4" />
                        القرعة
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => signOut()} className="text-destructive cursor-pointer">
                      <LogOut className="ml-2 h-4 w-4" />
                      تسجيل الخروج
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="outline" className="text-sm px-3 sm:px-4 bg-transparent">
                    <span className="hidden xs:inline">تسجيل الدخول</span>
                    <span className="xs:hidden">دخول</span>
                  </Button>
                </Link>
                <Link href="/register">
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground text-sm px-3 sm:px-4">
                    <span className="hidden xs:inline">إنشاء حساب</span>
                    <span className="xs:hidden">تسجيل</span>
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
